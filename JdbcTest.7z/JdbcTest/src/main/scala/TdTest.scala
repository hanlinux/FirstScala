import java.sql.{Connection, DriverManager, ResultSet}

import org.apache.spark.Logging

object TdTest extends App with Logging{
    DriverManager.registerDriver(new com.teradata.jdbc.TeraDriver())
    
    val url = "jdbc:teradata://{IP}/{name}"
    val user = "test"
    val password = "test"
    
    val conn: Connection = DriverManager
        .getConnection(url, user, password)
    
    val res: ResultSet = conn.createStatement
        .executeQuery("select * from {DB}.{TABLE} ")
    
    println(res.getMetaData.getColumnCount)
    
    var count = 0
    while (res.next() && count < 10) {
        count += 1
        println(res.getString(4))
    }

    conn.close()
}

