package com.obank.di.driver

import com.obank.di.utils.{ConfgurationUtils, SparkSessionUtils}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.permission.FsPermission
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SaveMode

object TdEtl extends App {
    
    var configPath: String = "conf/main/conf.yaml"
    
    parseArgs()
    
    Logger.getLogger("org.apache").setLevel(Level.ERROR)
    
    val mainConf = ConfgurationUtils.getYamlConf(configPath)
    
    val sparkSession = SparkSessionUtils.getSparkSession(mainConf)
    
    val jdbcUrl = mainConf.parameters.get("url").mkString
    val sqlFolder = mainConf.parameters.get("sql.folder").mkString
    
    val hadoopConf: Configuration = sparkSession.sparkContext.hadoopConfiguration
    val fileIt = FileSystem.get(hadoopConf).listFiles(new Path(sqlFolder), true)
    var filePathList = List[Path]()
    
    while (fileIt.hasNext) {
        val fileInfo = fileIt.next()
        filePathList = fileInfo.getPath :: filePathList
    }
    
    filePathList.map(configPath => {
        //        "user": "jerryhan"
        //        "password": "!QAZ2wsx3edc"
        //        "output.base.dir": ""
        //        "output.db": "PCORE_VW"
        //        "output.table": "RD_BK_JOB_TITLE_CD"
        //        "sql": "select count(Job_Title_Cd) a from PCORE_VW.RD_BK_JOB_TITLE_CD"
        
        val queryConf = ConfgurationUtils.getYamlConf(FileSystem.get(hadoopConf).open(configPath))
        
        val user = queryConf.parameters.get("user").mkString
        val password = queryConf.parameters.get("password").mkString
        val outputBaseDir = queryConf.parameters.get("output.base.dir").mkString
        val outputDb = queryConf.parameters.get("output.db").mkString
        val outputTable = queryConf.parameters.get("output.table").mkString
        val querySql = "( " + queryConf.parameters.get("sql").mkString + " ) temp"
        
        val outputPath = (if (outputBaseDir.isEmpty) ("") else (outputBaseDir + "/")) + outputDb + "/" + outputTable
        
        sparkSession.read
            .format("jdbc")
            .option("driver", "com.teradata.jdbc.TeraDriver")
            .option("url", jdbcUrl)
            .option("user", user)
            .option("password", password)
            .option("dbtable", querySql)
            .load()
            .write
            .mode(SaveMode.Overwrite)
            .csv(outputPath)
    
        FileSystem.get(hadoopConf).setPermission(new Path(outputPath), FsPermission.valueOf("drwxrwxrwx"))
    })
    
    def parseArgs(): Unit = {
        val argList = args.sliding(2, 1).toList
        argList.collect {
            case Array("--conf", configPath: String) => this.configPath = configPath
        }
    }
}

