package com.obank.di.utils

import org.apache.spark.sql.SparkSession

object SparkSessionUtils {
    def getSparkSession(yamlConf: YamlConf): SparkSession = {
        val sparkSessionBuild = SparkSession
            .builder()
        //    .master("local") // change to "yarn-client" on YARN
        //    .config("spark.driver.cores", "1")
        //    .config("spark.driver.memory", "1g")
        //    .config("spark.executor.cores", "2")
        //    .config("spark.executor.memory", "1g")
        //    .appName("Hello")

        yamlConf.parameters
            .filterKeys(_.startsWith("spark"))
            .foreach(para => {
                println(s"${para._1} + ", s" + ${para._2}")
                sparkSessionBuild.config(para._1, para._2)
            })

        val sparkSesion = sparkSessionBuild.getOrCreate()

        return sparkSesion
    }
}
