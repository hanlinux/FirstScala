package com.obank.di.utils

import java.util.{List => JList, Map => JMap}

import com.fasterxml.jackson.annotation.JsonProperty
import com.google.common.base.Preconditions

import scala.collection.JavaConversions._

class YamlConf(@JsonProperty("parameters") _parameters: JMap[String, String]) {

  val errMsg: String = "parameters cannot be null"
  val parameters: Map[String, String] =
    Preconditions.checkNotNull(_parameters, errMsg, null).toMap[String, String]

}
