package com.obank.di.utils

import java.io.{FileReader, InputStream}

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory

object ConfgurationUtils {

  def getYamlConf(configPath: String = "conf/main/conf.yaml"): YamlConf = {
    
    val reader = new FileReader(configPath)
    val mapper = new ObjectMapper(new YAMLFactory())

    mapper.readValue(reader, classOf[YamlConf])
  }
  
  def getYamlConf(inputStream: InputStream): YamlConf = {
    
    val mapper = new ObjectMapper(new YAMLFactory())
    
    mapper.readValue(inputStream, classOf[YamlConf])
  }
}
